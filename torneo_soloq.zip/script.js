document.addEventListener("DOMContentLoaded", function() {
    function updateWinrate() {
        const rows = document.querySelectorAll("#leaderboard tbody tr");
        rows.forEach(row => {
            const wins = parseInt(row.children[6].innerText) || 0;
            const losses = parseInt(row.children[7].innerText) || 0;
            const gamesPlayed = wins + losses;
            row.children[5].innerText = gamesPlayed;
            row.children[8].innerText = gamesPlayed ? ((wins / gamesPlayed) * 100).toFixed(1) + "%" : "0%";
        });
    }

    function updateTotal(tableSelector, totalClass) {
        const rows = document.querySelectorAll(`${tableSelector} tbody tr`);
        rows.forEach(row => {
            const cells = row.querySelectorAll("td[contenteditable='true']");
            const totalCell = row.querySelector(totalClass);

            function calculateTotal() {
                let total = 0;
                cells.forEach(cell => {
                    total += parseInt(cell.innerText) || 0;
                });
                totalCell.innerText = total;
                updateWinrate();
            }

            cells.forEach(cell => {
                cell.addEventListener("input", calculateTotal);
            });
        });
    }

    updateTotal("#leaderboard", ".total");
    updateTotal("#match-points", ".match-total");
});
